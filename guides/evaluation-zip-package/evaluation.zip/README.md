---
key: "singleturn-generic-input"
display_name: "Single-turn Solver Generic Input"
num_tasks: 1
tags: ["Guides"]
description: "Evaluates whether a model correctly answers single-turn factual questions using a generic input builder."
---
## Overview

This evaluation tests whether a model can answer straightforward factual questions with
exact single-word responses. Responses are scored with an exact-string match against
the expected answer.

## Motivation

Factual accuracy is a baseline requirement for any useful model. This evaluation
provides a fast, deterministic check that a model returns correct answers to
unambiguous questions — without relying on a judge model.

## Methodology

1. **Test Cases**: Each sample contains a factual question and a single expected answer.
2. **Model Response**: The model receives the question and produces a response.
3. **Scoring**: The response is compared against the expected answer using exact string matching.

## Metrics

### Accuracy

The proportion of responses that exactly match the expected answer (range: 0.0 to 1.0).

## Scoring

### String Equals Scorer

- **1.0**: The model's response exactly matches the expected answer.
- **0.0**: The model's response does not match the expected answer.
