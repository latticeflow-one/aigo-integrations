# How to run: Single-turn Solver Generic Input

## 1. Create your AI app

Consult the integration guide for reference (if needed):

- AI app: https://github.com/latticeflow-one/aigo-integrations/tree/latest/guides/ai-app-full

Then add your app and switch to it:

```
lf app add -f app.yaml
lf switch <your-app-key>
```

## 2. Add your model under test

Consult one of the integration guides (if needed):

- Custom inference endpoint: https://github.com/latticeflow-one/aigo-integrations/tree/latest/guides/model-custom-inference
- OpenAI chat completion: https://github.com/latticeflow-one/aigo-integrations/tree/latest/guides/model-openai-chat-completion

Then add the model:

```
lf model add -f model.yaml
```

## 3. Configure the Evaluation

Set the following key in `.env`:

```
# The key of the model under test integrated in step 2.
MODEL_KEY="<your-model-key>"
```

## 4. Run the evaluation

```
lf run -f run.yaml
```
